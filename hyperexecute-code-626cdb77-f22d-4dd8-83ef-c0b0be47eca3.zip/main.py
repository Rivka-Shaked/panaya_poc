import json
import os

# File Path
print("🔍 Searching for settings.json file...")
json_file_path = r"C:\Users\ltuser.ghtestVM\AppData\Local\Agent\config\settings.json"

# Step 1: Open the Agent application (if needed)
# subprocess.Popen(r"C:\Path\To\Agent.exe")  # Uncomment if Agent is not already running

# New Values to Update
new_values = {
    "panayaUrl": "https://emea.panaya.com/",
    "systemUid": "_4d710da2_19536b42a4f_3fab",
    "userName": "sudhirj@lambdatest.com",
    "agentName": os.getenv("TASK_ID"),
    "tags": os.getenv("TASK_ID"),
    "apiToken": "sudhirj@lambdatest.com:tc53k7/x8kC4a9+4nUJXLN4TcMqOxChiLFT0NF3I9hu7iMzYg4Ge+tFq3RGu3clSfMqkKirvVupkEDcW2ukhPHfxdb/A/itH3IsVXq9eeCconWqgKtl0hExQsB5Yvczaqc+3uZGFY1AFe+pvioW5AgIrynT9u0mCWN/ZcGBpkI0UknUPLTg9iYC3W8OsEZ4m1cVF8h42ZOvNhyxTkDj1JjnmqSgWlJZrmYebzICg6MYWG8Q6Nf/wQo45cb4xQUdS6uTqua/rE9a8vct8s4cFAi6iycl1TLLIQ5p/9uH8U1OLK/1/PpEZ7+s2oKybvh7x58rsT5Wz0uWhYUI4+lFTjYVXvplNgitR1LgtPEAUVSk5MGu6eWnt8GMyP29atj14OjClteMY0zooSZjPTeO3T6VyHBFfIpYQSH5ZvNltTdI=",
    "cloudAgent": True
}

# Read JSON File
with open(json_file_path, 'r') as file:
    data = json.load(file)
    print("Previous JSON Data:")
    print(json.dumps(data, indent=4))

# Update JSON Values
for key, value in new_values.items():
    if key in data:
        data[key] = value

# Write Updated JSON
with open(json_file_path, 'w') as file:
    json.dump(data, file, indent=4)

print("✅ JSON File Updated Successfully")

print("Updated JSON Data:")
print(json.dumps(data, indent=4))

# Restart Agent
print("Restarting Agent...")
os.system(r"type C:\Users\ltuser.ghtestVM\AppData\Local\Agent\config\settings.json") 
exe_path = r"C:\Program Files\Panaya\Agent\Agent.exe"
args = ["--start"]

subprocess.Popen([exe_path] + args, creationflags=subprocess.DETACHED_PROCESS)

print("🔥 Panaya Agent Restarted")

subprocess.Popen([exe_path] + args, creationflags=subprocess.DETACHED_PROCESS)

print("🔥 Panaya Agent Restarted")


time.sleep(30)  # Wait for it to load

# Step 2: Bring the "Agent" window to the front
windows = gw.getWindowsWithTitle("Agent")  # Get the Agent settings window

if windows:
    agent_window = windows[0]

    # Use pywinauto to bring the window to the front and ensure focus
    app = pywinauto.Application().connect(handle=agent_window._hWnd)
    app_window = app.window(handle=agent_window._hWnd)
    
    # Bring the window to the front and focus on it
    app_window.minimize()  # First minimize it to avoid being hidden
    app_window.restore()   # Restore it to bring to the front
    app_window.set_focus()  # Ensure it gets focus

    time.sleep(1)  # Wait for focus
    print(pyautogui.position())  # Debugging: Check current mouse position
    pyautogui.click(1405, 69)  # Adjust coordinates for the hamburger icon
    time.sleep(1)  # Give time for the menu to open
    print(pyautogui.position())  # Debugging output
    pyautogui.click(1245, 162)  # Adjust coordinates for tag option selection
    time.sleep(1)  # Time to select
    print(pyautogui.position())  # Debugging output

    # Step 3: Focus on the window and interact
    app_window.set_focus() 
    time.sleep(random.uniform(0.5, 1))  # Ensure the window is focused
    pyautogui.press("tab")
    time.sleep(random.uniform(0.5, 1))   # Navigate to the next field
    pyautogui.press("tab") 
    time.sleep(random.uniform(0.5, 1))  # If needed to tab again
    pyautogui.press("enter")  # Confirm the action
    pyautogui.write('Ritam1')

    # Step 4: Use Tab to navigate to "Save Settings"
    for _ in range(1):  # Adjust if needed
        pyautogui.press("tab")
        time.sleep(random.uniform(0.2, 0.5))
        time.sleep(0.2)

    # Step 5: Press Enter to click "Save Settings"
    #pyautogui.press("enter")
    print("Clicked 'Save Settings' button.")
else:
    print("Agent settings window not found.")

